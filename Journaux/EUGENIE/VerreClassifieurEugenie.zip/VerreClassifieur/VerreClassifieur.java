import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;


public class VerreClassifieur
{
	public static final String TAB = "|  "; //Change d'une représentation à l'autre
	public static final int NBSPACE = TAB.length(); //Change d'une représentation à l'autre

	public static final int NBPARAM = 10;

	public double RI;
	public double Na;
	public double Mg;
	public double Al;
	public double Si;
	public double K;
	public double Ca;
	public double Ba;
	public double Fe;
	public int Classe;

	public VerreClassifieur(String[] strs)
	{
		RI = Double.parseDouble(strs[0]);
		Na = Double.parseDouble(strs[1]);
		Mg = Double.parseDouble(strs[2]);
		Al = Double.parseDouble(strs[3]);
		Si = Double.parseDouble(strs[4]);
		K = Double.parseDouble(strs[5]);
		Ca = Double.parseDouble(strs[6]);
		Ba = Double.parseDouble(strs[7]);
		Fe = Double.parseDouble(strs[8]);

		Classe = Integer.parseInt(strs[9].replace("Classe ", ""));
	}

	private static String readLine(FileInputStream fis) throws IOException //Retourne un ligne complète du document
	{
		String str = "";
		int c;
		while((fis.available()!=0)&&((c=fis.read())!='\n'))
		{
			str+=(char)c;
		}
		return str.replaceAll("\\(.*\\)$", "");
	}

	private static String makeTab(int prof) //Retourne une suite de tabulation en fonction de la profondeur
	{
		String str="";
		for(int i = 0; i <= prof+1;i++)
		{
			str+="\t";
		}
		return str;
	}

	private static boolean isLeaf(String str) //Vérifie si on traite une feuille
	{
		if(str.contains(":"))
		{
			return true;
		}
		return false;
	}

	private static String onLeaf(String str, int newProf, int ancProf, boolean wereALeaf) //Traitement sur une feuille
	{
		String str2 = "";
		for(int i = ancProf;i>newProf;i--)
		{
			String tabs = makeTab(i-1);
			str2+=tabs+"}\n";
		}
		String tabs = makeTab(newProf);
		if(ancProf<newProf)
		{
			str2+=tabs+"if(verre.";
			str2+=str.replace(TAB, "").replaceAll(":.*", "")+")\n";
		}
		else
		{
			if(!wereALeaf)
			{
				str2+=tabs+"}\n";
			}
			str2+=tabs+"else\n";
		}
		str2+=tabs+"{\n";
		str2+=tabs+"\t";
		str2+="return " + str.replaceAll(".*Classe ", "").substring(0, 1)+";\n";
		str2+=tabs+"}\n";
		return str2;
	}

	private static String onNode(String str, int newProf, int ancProf,boolean wereALeaf) //Traitement sur un noeuds
	{
		String str2="";
		for(int i = ancProf;i>newProf;i--)
		{
			String tabs = makeTab(i-1);
			str2+=tabs+"}\n";
		}
		String tabs = makeTab(newProf);
		if(newProf>ancProf)
		{
			str2+=tabs+"if(verre.";
			str2+=str.replace(TAB, "").replaceAll(":.*", "")+")\n";
		}
		else
		{
			if(!wereALeaf)
			{
				str2+=tabs+"}\n";
			}
			str2+=tabs+"else\n";
		}
		str2+=tabs+"{\n";
		return str2;
	}

	private static void fromWekaToJava(String name) throws IOException //Converti un arbre textuel de Weka en fonction java (Nombre d'accolade fermante sur la fin n'est pas toujours exacte)
	{
		File f = new File("AFile");
		File f2 = new File("Trees/"+name);
		FileInputStream fis = new FileInputStream(f);
		FileOutputStream fos = new FileOutputStream(f2);
		int ancProf = -1;
		int newProf = 0;
		boolean wereALeaf = false;

		fos.write(("\tpublic static int rule"+name+"(VerrePAUGAM verre)\n\t{\n").getBytes());

		while(fis.available()!=0)
		{
			String str = readLine(fis);
			newProf = str.lastIndexOf('|');
			if(newProf!=-1)
			{
				newProf/=NBSPACE;
			}
			newProf+=1;
			if(isLeaf(str))
			{
				fos.write(onLeaf(str, newProf,ancProf,wereALeaf).getBytes());
				wereALeaf = true;
			}
			else
			{
				fos.write(onNode(str, newProf,ancProf,wereALeaf).getBytes());
				wereALeaf = false;
			}
			ancProf=newProf;
		}
		fos.write("\t\t}\n\t}\n}".getBytes());
		fis.close();
		fos.close();
	}

	private static void testTree(String method) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException //Affiche la matrice de confusion en utilisant la méthode passée en paramètre
	{
		ArrayList<VerreClassifieur> list = new ArrayList<VerreClassifieur>();
		FileInputStream fis;
		try
		{
			fis = new FileInputStream("/home/rey-sama/Téléchargements/X_test.csv");
			char c;
			do
			{
				c=(char)fis.read();
			}while(c!='\n');
			int i=0;
			String[] strs = new String[10];
			do
			{
				String str = "";
				c=(char)fis.read();
				do
				{
					str+=c;
					c=(char)fis.read();
					if((int)c==65535)
					{
						break;
					}
				}while((c!=',')&&(c!='\n'));
				if((int)c==65535)
				{
					break;
				}
				strs[i]=str;
				//				System.out.println( i +  " "+str);
				i++;
				if(i==NBPARAM)
				{
					i=0;
					list.add(new VerreClassifieur(strs));
				}
			}while(c!=-1);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}


		int[][] matrice = new int[7][7];

		for(VerreClassifieur v : list)
		{
			int val = rules(v,method);
			matrice[v.Classe-1][val-1]+=1;
		}
		int[] pred = new int[7]; 
		for(int i = 0 ; i < 7 ; i++)
		{
			if(i==3)
			{
				continue;
			}
			int sum=0;
			for(int j = 0 ; j < 7 ; j++)
			{
				if(j==3)
				{
					continue;
				}
				sum+=matrice[i][j];
				pred[j]+=matrice[i][j];
				System.out.print(matrice[i][j]+"\t");
			}
			System.out.println("|\t"+sum+"\t"+matrice[i][i]*10000/sum/100.0);
		}
		int sum=0;
		for(int j = 0 ; j < 7 ; j++)
		{
			if(j==3)
			{
				continue;
			}
			sum+=pred[j];
			System.out.print(pred[j]+"\t");
		}
		System.out.println("|\t"+sum);
		int sum2=0;
		for(int j = 0 ; j < 7 ; j++)
		{
			if(j==3)
			{
				continue;
			}
			sum2+=matrice[j][j];
			try
			{
				System.out.print(matrice[j][j]*10000/pred[j]/100.0+"\t");
			}
			catch(ArithmeticException e)
			{
				System.out.print("Nan\t");
			}
		}
		System.out.println("|\t\t"+10000*sum2/sum/100.0);
	}

	public String toString()
	{
		String str = "RI = " + RI + "\n";
		str += "Na = " + Na + "\n";
		str += "Mg = " + Mg + "\n";
		str += "Al = " + Al + "\n";
		str += "Si = " + Si + "\n";
		str += "K = " + K + "\n";
		str += "Ca = " + Ca + "\n";
		str += "Ba = " + Ba + "\n";
		str += "Fe = " + Fe + "\n";
		str += "Classe = " + Classe + "\n";
		return str;
	}

	//MAIN
	public static void main(String [] args) throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		String method = "SimpleCard_N1";
		method = method.replaceAll("^rule", "");
		int A=1;
		if(A==0)
		{
			fromWekaToJava(method);
		}
		else
		{
			testTree("rule"+method);
		}
		System.out.println("\n\n");
	}

	private static int rules(VerreClassifieur verre, String method) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
	{
		Method m =  VerreClassifieur.class.getMethod(method, VerreClassifieur.class);
		return (int) m.invoke(null,verre);
	}

	//Les méthodes générées
	
	public static int ruleJ48_0_0__5_0_2_3_0_0_1_1_0_0_Cross10(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									return 3;
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				return 2;
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleJ48Graft_0__25_0_2_0_0_1_0_0_Cross10(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							if(verre.Ca <= -0.585203)
							{
								if(verre.Na <= -0.129502)
								{
									if(verre.K <= 0.0402)
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									if(verre.RI <= -0.133583)
									{
										return 1;
									}
									else
									{
										return 3;
									}
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				if(verre.Ba <= 3.300807)
				{
					return 7;
				}
				else
				{
					if(verre.Na <= 0.789634)
					{
						if(verre.K <= -0.217866)
						{
							return 7;
						}
						else
						{
							if(verre.Al <= 1.097314)
							{
								return 7;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						return 7;
					}
				}
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleRandomTree_0_0_0_0_1_0_1_TrainingSet(VerreClassifieur verre)
	{
		if(verre.Al < 0.62)
		{
			if(verre.K < -0.69)
			{
				if(verre.RI < 0.84)
				{
					if(verre.Na < 0.53 )
					{
						return 2;
					}
					else
					{
						return 6;
					}
				}
				else
				{
					if(verre.Mg < -0.5 )
					{
						return 2;
					}
					else
					{
						return 3;
					}
				}
			}
			else
			{
				if(verre.Al < -0.09)
				{
					if(verre.Ca < 1.19)
					{
						if(verre.RI < -0.38)
						{
							if(verre.RI < -0.8 )
							{
								return 1;
							}
							else
							{
								if(verre.Ca < -0.5 )
								{
									return 2;
								}
								else
								{
									if(verre.Na < -0.49)
									{
										if(verre.Na < -0.63 )
										{
											return 3;
										}
										else
										{
											return 2;
										}
									}
									else
									{
										return 3;
									}
								}
							}
						}
						else
						{
							if(verre.Mg < 0.65)
							{
								if(verre.Al < -1.13 )
								{
									return 2;
								}
								else
								{
									if(verre.RI < 1.5 )
									{
										return 1;
									}
									else
									{
										return 7;
									}
								}
							}
							else
							{
								if(verre.Ca < -0.25)
								{
									if(verre.Mg < 0.73)
									{
										if(verre.RI < -0.02 )
										{
											return 1;
										}
										else
										{
											return 2;
										}
									}
									else
									{
										return 2;
									}
								}
								else
								{
									if(verre.K < 0.14)
									{
										if(verre.Al < -1.47)
										{
											if(verre.Na < 0.31 )
											{
												return 3;
											}
											else
											{
												if(verre.Al < -1.73 )
												{
													return 1;
												}
												else
												{
													return 3;
												}
											}
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 2;
									}
								}
							}
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.Ca < 1.56)
					{
						if(verre.Mg < 0.53)
						{
							if(verre.Mg < 0.46 )
							{
								return 2;
							}
							else
							{
								if(verre.K < 0.03 )
								{
									return 2;
								}
								else
								{
									return 3;
								}
							}
						}
						else
						{
							if(verre.Ca < -0.41)
							{
								if(verre.Al < 0.13 )
								{
									return 2;
								}
								else
								{
									if(verre.Si < 0.4 )
									{
										return 2;
									}
									else
									{
										if(verre.RI < -0.6 )
										{
											return 1;
										}
										else
										{
											return 2;
										}
									}
								}
							}
							else
							{
								if(verre.Si < -0.08 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
						}
					}
					else
					{
						return 5;
					}
				}
			}
		}
		else
		{
			if(verre.Ba < 0.26)
			{
				if(verre.Al < 1.16)
				{
					if(verre.Si < 0.96 )
					{
						return 2;
					}
					else
					{
						return 5;
					}
				}
				else
				{
					if(verre.Ca < 1.08 )
					{
						return 5;
					}
					else
					{
						return 6;
					}
				}
			}
			else
			{
				if(verre.Si < -2.91)
				{
					if(verre.RI < 1.81 )
					{
						return 5;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 7;
				}
			}
		}
	}

	public static int ruleRandomTree_0_0_0_0_1_3_1_Cross10(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						return 3;
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					return 5;
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleSimpleCart_0_1_2_5_1_1_1_0_Cross10(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						if(verre.Si < 0.06122816543815525)
						{
							return 3;
						}
						else
						{
							if(verre.RI < -0.796507315176076)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								if(verre.RI < 1.2029877188001021)
								{
									return 3;
								}
								else
								{
									return 1;
								}
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					if(verre.Na < 0.24540881467108988)
					{
						return 5;
					}
					else
					{
						return 6;
					}
				}
				else
				{
					if(verre.K < -0.6592953464118319)
					{
						return 6;
					}
					else
					{
						if(verre.Fe < 1.773983111784764)
						{
							if(verre.Ca < -0.4103638583227195)
							{
								if(verre.Ca < -0.805651876509383)
								{
									return 2;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								if(verre.RI < 0.05403748926772576)
								{
									if(verre.Na < -0.353239345608925)
									{
										if(verre.RI < -0.28725254780949727)
										{
											return 2;
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 3;
									}
								}
								else
								{
									return 2;
								}
							}
						}
						else
						{
							return 1;
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si < -2.910657107003131)
			{
				return 2;
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleSimpleCart_0_1_2_5_1_1_0_1_Cross10(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						return 3;
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					return 5;
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N2(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									return 3;
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				return 2;
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleJ48_N3(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							if(verre.Al <= -0.423003)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N4(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.122579)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N5(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 0.958188)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.519108)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48Gaft_N2(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							if(verre.Ca <= -0.585203)
							{
								if(verre.Na <= -0.129502)
								{
									if(verre.K <= 0.0402)
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									if(verre.RI <= -0.133583)
									{
										return 1;
									}
									else
									{
										return 3;
									}
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				if(verre.Ba <= 3.300807)
				{
					return 7;
				}
				else
				{
					if(verre.Na <= 0.789634)
					{
						if(verre.K <= -0.217866)
						{
							return 7;
						}
						else
						{
							if(verre.Al <= 1.097314)
							{
								return 7;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						return 7;
					}
				}
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleJ48Gaft_N3(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							if(verre.Ca <= -0.585203)
							{
								if(verre.Na <= -0.129502)
								{
									if(verre.K <= 0.0402)
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							if(verre.Al <= -0.423003)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								if(verre.RI <= -0.133583)
								{
									return 1;
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48Gaft_N4(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.122579)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								if(verre.RI <= -0.133583)
								{
									return 1;
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleSimpleCard_N2_S1(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						return 3;
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					return 5;
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleSimpleCard_N3_S1(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						if(verre.Si < 0.06122816543815525)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					return 5;
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleSimpleCard_N3_S2(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						if(verre.Si < 0.06122816543815525)
						{
							return 3;
						}
						else
						{
							if(verre.RI < -0.796507315176076)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					if(verre.Na < 0.24540881467108988)
					{
						return 5;
					}
					else
					{
						return 6;
					}
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleSimpleCard_N4_S1(VerreClassifieur verre)
	{
		if(verre.Ba < 0.2852027452392228)
		{
			if(verre.Al < -0.08515487904007185)
			{
				if(verre.Ca < 1.1859915997388053)
				{
					if(verre.RI < -0.3765954894527859)
					{
						if(verre.Si < 0.06122816543815525)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Mg < 0.7348175252325105)
						{
							return 1;
						}
						else
						{
							if(verre.RI < 0.6562089159433073)
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Mg < -0.5354698055780083)
				{
					return 5;
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleRandomK1_S1(VerreClassifieur verre)
	{
		if(verre.K < -0.63)
		{
			if(verre.Si < 0.16)
			{
				if(verre.RI < 0.46 )
				{
					return 6;
				}
				else
				{
					if(verre.Ca < 0.29 )
					{
						return 1;
					}
					else
					{
						if(verre.Ca < 0.6 )
						{
							return 3;
						}
						else
						{
							return 1;
						}
					}
				}
			}
			else
			{
				if(verre.Fe < -0.24)
				{
					if(verre.RI < -0.14)
					{
						if(verre.Al < -0.74 )
						{
							return 6;
						}
						else
						{
							return 7;
						}
					}
					else
					{
						if(verre.Al < -1.52)
						{
							if(verre.Si < 1.78 )
							{
								return 6;
							}
							else
							{
								return 2;
							}
						}
						else
						{
							return 2;
						}
					}
				}
				else
				{
					return 7;
				}
			}
		}
		else
		{
			if(verre.Ba < -0.02)
			{
				if(verre.Ba < -0.27)
				{
					if(verre.K < 0.17)
					{
						if(verre.K < 0.03)
						{
							if(verre.RI < 0.25)
							{
								if(verre.Si < -0.23 )
								{
									return 2;
								}
								else
								{
									if(verre.K < 0.01)
									{
										if(verre.Al < -0.19)
										{
											if(verre.K < -0.43 )
											{
												return 3;
											}
											else
											{
												if(verre.Ca < -0.39 )
												{
													return 2;
												}
												else
												{
													if(verre.RI < -0.27 )
													{
														return 3;
													}
													else
													{
														return 2;
													}
												}
											}
										}
										else
										{
											if(verre.Si < 0.48)
											{
												if(verre.Ca < -0.66 )
												{
													return 1;
												}
												else
												{
													return 2;
												}
											}
											else
											{
												return 2;
											}
										}
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								if(verre.RI < 1.16)
								{
									if(verre.Ca < 0.5 )
									{
										return 1;
									}
									else
									{
										if(verre.RI < 1.1)
										{
											if(verre.K < -0.35 )
											{
												return 5;
											}
											else
											{
												if(verre.Si < -0.23 )
												{
													return 2;
												}
												else
												{
													return 5;
												}
											}
										}
										else
										{
											return 3;
										}
									}
								}
								else
								{
									if(verre.Al < -0.97 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
						}
						else
						{
							if(verre.K < 0.05 )
							{
								return 1;
							}
							else
							{
								if(verre.Na < -0.69)
								{
									if(verre.Al < 0.06 )
									{
										return 1;
									}
									else
									{
										if(verre.Si < 0.73 )
										{
											return 1;
										}
										else
										{
											return 5;
										}
									}
								}
								else
								{
									if(verre.Na < -0.37)
									{
										if(verre.Na < -0.66)
										{
											if(verre.Ca < -0.19 )
											{
												return 1;
											}
											else
											{
												return 3;
											}
										}
										else
										{
											if(verre.Si < 0.18 )
											{
												return 2;
											}
											else
											{
												if(verre.Al < -0.09)
												{
													if(verre.Mg < 0.44 )
													{
														return 2;
													}
													else
													{
														if(verre.K < 0.06 )
														{
															return 2;
														}
														else
														{
															return 1;
														}
													}
												}
												else
												{
													return 2;
												}
											}
										}
									}
									else
									{
										if(verre.Al < -0.24)
										{
											if(verre.Ca < -0.28)
											{
												if(verre.Na < -0.02)
												{
													if(verre.Fe < -0.03)
													{
														if(verre.Na < -0.23 )
														{
															return 1;
														}
														else
														{
															if(verre.RI < -0.07 )
															{
																return 1;
															}
															else
															{
																return 2;
															}
														}
													}
													else
													{
														return 1;
													}
												}
												else
												{
													if(verre.Mg < 0.76)
													{
														if(verre.Na < 0.03 )
														{
															return 3;
														}
														else
														{
															return 1;
														}
													}
													else
													{
														return 2;
													}
												}
											}
											else
											{
												if(verre.RI < 1.1 )
												{
													return 1;
												}
												else
												{
													return 7;
												}
											}
										}
										else
										{
											if(verre.Si < 0.13)
											{
												if(verre.K < 0.09 )
												{
													return 3;
												}
												else
												{
													if(verre.Na < -0.3 )
													{
														return 3;
													}
													else
													{
														return 1;
													}
												}
											}
											else
											{
												return 2;
											}
										}
									}
								}
							}
						}
					}
					else
					{
						if(verre.Mg < -0.91)
						{
							if(verre.Na < -1.53 )
							{
								return 2;
							}
							else
							{
								return 5;
							}
						}
						else
						{
							if(verre.Fe < 1.15 )
							{
								return 2;
							}
							else
							{
								if(verre.Na < -0.5 )
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
						}
					}
				}
				else
				{
					if(verre.Mg < 0.33 )
					{
						return 2;
					}
					else
					{
						if(verre.Fe < 0.28 )
						{
							return 1;
						}
						else
						{
							if(verre.Mg < 0.6 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
				}
			}
			else
			{
				if(verre.K < 0.2)
				{
					if(verre.K < -0.25 )
					{
						return 7;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.Ba < 1.01 )
					{
						return 5;
					}
					else
					{
						if(verre.Si < -2.91 )
						{
							return 5;
						}
						else
						{
							return 7;
						}
					}
				}
			}
		}
	}

	public static int ruleRandomK1_S2(VerreClassifieur verre)
	{
		if(verre.RI < -0.28)
		{
			if(verre.Fe < 0.38)
			{
				if(verre.Al < 0.62)
				{
					if(verre.RI < -0.88)
					{
						if(verre.K < -0.33 )
						{
							return 6;
						}
						else
						{
							return 1;
						}
					}
					else
					{
						if(verre.Al < -0.13)
						{
							if(verre.Si < 0.06 )
							{
								return 3;
							}
							else
							{
								if(verre.RI < -0.42)
								{
									if(verre.K < 0.03 )
									{
										return 3;
									}
									else
									{
										return 2;
									}
								}
								else
								{
									return 1;
								}
							}
						}
						else
						{
							if(verre.Si < 0.48)
							{
								if(verre.Mg < 0.59 )
								{
									return 2;
								}
								else
								{
									if(verre.Na < 0.03 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					if(verre.Ca < -0.54)
					{
						if(verre.Na < -0.62 )
						{
							return 2;
						}
						else
						{
							if(verre.Mg < 0.14 )
							{
								return 5;
							}
							else
							{
								if(verre.K < 1.24 )
								{
									return 2;
								}
								else
								{
									return 7;
								}
							}
						}
					}
					else
					{
						if(verre.K < 0.05 )
						{
							return 7;
						}
						else
						{
							return 5;
						}
					}
				}
			}
			else
			{
				if(verre.Fe < 1.77)
				{
					if(verre.Mg < 0.51 )
					{
						return 2;
					}
					else
					{
						if(verre.RI < -0.56 )
						{
							return 2;
						}
						else
						{
							return 3;
						}
					}
				}
				else
				{
					if(verre.RI < -0.66 )
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
			}
		}
		else
		{
			if(verre.Al < 0.01)
			{
				if(verre.Fe < -0.29)
				{
					if(verre.K < 0.03)
					{
						if(verre.RI < 0.25)
						{
							if(verre.Ca < -0.08 )
							{
								return 2;
							}
							else
							{
								if(verre.Si < 1.45 )
								{
									return 3;
								}
								else
								{
									return 2;
								}
							}
						}
						else
						{
							if(verre.K < -0.69)
							{
								if(verre.Mg < -0.5)
								{
									if(verre.RI < 1.8 )
									{
										return 6;
									}
									else
									{
										return 2;
									}
								}
								else
								{
									return 3;
								}
							}
							else
							{
								if(verre.Al < -0.62)
								{
									if(verre.Na < 0.55 )
									{
										return 1;
									}
									else
									{
										if(verre.K < -0.61 )
										{
											return 1;
										}
										else
										{
											if(verre.Mg < 0.77 )
											{
												return 3;
											}
											else
											{
												return 1;
											}
										}
									}
								}
								else
								{
									if(verre.Si < -0.72)
									{
										if(verre.Si < -1.65 )
										{
											return 2;
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 2;
									}
								}
							}
						}
					}
					else
					{
						if(verre.Mg < 0.73)
						{
							if(verre.K < 0.1 )
							{
								return 1;
							}
							else
							{
								if(verre.Ca < -0.13 )
								{
									return 1;
								}
								else
								{
									return 7;
								}
							}
						}
						else
						{
							return 2;
						}
					}
				}
				else
				{
					if(verre.Al < -0.97)
					{
						if(verre.RI < 0.62 )
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
					else
					{
						if(verre.Mg < 0.7)
						{
							if(verre.Si < 0.3)
							{
								if(verre.Al < -0.64 )
								{
									return 2;
								}
								else
								{
									if(verre.Al < -0.21 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 1;
							}
						}
						else
						{
							return 2;
						}
					}
				}
			}
			else
			{
				if(verre.Ca < 0.15)
				{
					if(verre.Ca < -1.16 )
					{
						return 7;
					}
					else
					{
						if(verre.Si < -0.08)
						{
							if(verre.Si < -1.11 )
							{
								return 2;
							}
							else
							{
								if(verre.Na < -0.25 )
								{
									return 2;
								}
								else
								{
									return 3;
								}
							}
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.K < -0.62 )
					{
						return 6;
					}
					else
					{
						if(verre.Al < 0.24 )
						{
							return 5;
						}
						else
						{
							if(verre.Ca < 2.6)
							{
								if(verre.Si < -0.98 )
								{
									return 2;
								}
								else
								{
									if(verre.Si < -0.1)
									{
										if(verre.Ca < 0.59 )
										{
											return 2;
										}
										else
										{
											return 5;
										}
									}
									else
									{
										return 5;
									}
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
			}
		}
	}

	public static int ruleRandomK1_S3(VerreClassifieur verre)
	{
		if(verre.Na < 0.69)
		{
			if(verre.Al < -0.06)
			{
				if(verre.Ca < 1.19)
				{
					if(verre.Al < -0.47)
					{
						if(verre.Na < 0.04)
						{
							if(verre.Ba < -0.27)
							{
								if(verre.Al < -1.16 )
								{
									return 2;
								}
								else
								{
									if(verre.Fe < 2.08)
									{
										if(verre.Si < 0.56)
										{
											if(verre.Ca < 0.1)
											{
												if(verre.Mg < 0.68 )
												{
													return 1;
												}
												else
												{
													return 2;
												}
											}
											else
											{
												return 1;
											}
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI < 0.1)
							{
								if(verre.Na < 0.17 )
								{
									return 1;
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 1;
							}
						}
					}
					else
					{
						if(verre.Ba < -0.27)
						{
							if(verre.Si < 0.42)
							{
								if(verre.Ca < -0.03)
								{
									if(verre.Mg < 0.71)
									{
										if(verre.Mg < 0.64)
										{
											if(verre.Fe < 0.64)
											{
												if(verre.Na < -0.24)
												{
													if(verre.Ca < -0.21 )
													{
														return 1;
													}
													else
													{
														if(verre.K < 0.09 )
														{
															return 2;
														}
														else
														{
															return 3;
														}
													}
												}
												else
												{
													if(verre.Mg < 0.5 )
													{
														return 3;
													}
													else
													{
														if(verre.Ca < -0.49 )
														{
															return 2;
														}
														else
														{
															if(verre.Na < -0.09 )
															{
																return 3;
															}
															else
															{
																return 2;
															}
														}
													}
												}
											}
											else
											{
												return 2;
											}
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 2;
									}
								}
								else
								{
									if(verre.Fe < 0.84)
									{
										if(verre.Ca < 0 )
										{
											return 7;
										}
										else
										{
											return 1;
										}
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								if(verre.Fe < -0.29)
								{
									if(verre.Na < -0.56 )
									{
										return 1;
									}
									else
									{
										if(verre.Al < -0.4 )
										{
											return 1;
										}
										else
										{
											return 3;
										}
									}
								}
								else
								{
									return 1;
								}
							}
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				if(verre.Al < 0.49)
				{
					if(verre.Ca < 1.56)
					{
						if(verre.Ba < -0.25)
						{
							if(verre.RI < -0.21)
							{
								if(verre.Mg < 0.53 )
								{
									return 2;
								}
								else
								{
									if(verre.Fe < -0.24)
									{
										if(verre.RI < -0.68)
										{
											if(verre.Mg < 0.58 )
											{
												return 2;
											}
											else
											{
												if(verre.Ca < -0.81 )
												{
													return 1;
												}
												else
												{
													return 2;
												}
											}
										}
										else
										{
											return 2;
										}
									}
									else
									{
										if(verre.K < 0.17 )
										{
											return 1;
										}
										else
										{
											if(verre.Na < -0.5 )
											{
												return 1;
											}
											else
											{
												return 2;
											}
										}
									}
								}
							}
							else
							{
								if(verre.Al < 0.12 )
								{
									return 3;
								}
								else
								{
									if(verre.Al < 0.24 )
									{
										return 2;
									}
									else
									{
										if(verre.Ca < 0.62 )
										{
											return 3;
										}
										else
										{
											return 2;
										}
									}
								}
							}
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 5;
					}
				}
				else
				{
					if(verre.Ca < 2.6)
					{
						if(verre.Fe < 0.33)
						{
							if(verre.K < 0.42)
							{
								if(verre.Al < 0.58 )
								{
									return 5;
								}
								else
								{
									if(verre.Fe < -0.55 )
									{
										return 2;
									}
									else
									{
										return 7;
									}
								}
							}
							else
							{
								if(verre.Al < 0.67 )
								{
									return 7;
								}
								else
								{
									return 5;
								}
							}
						}
						else
						{
							if(verre.K < 0.22 )
							{
								return 3;
							}
							else
							{
								return 5;
							}
						}
					}
					else
					{
						return 2;
					}
				}
			}
		}
		else
		{
			if(verre.Al < 0.57)
			{
				if(verre.K < -0.69)
				{
					if(verre.Al < -0.51)
					{
						if(verre.Ca < -0.6 )
						{
							return 6;
						}
						else
						{
							if(verre.Si < -0.26 )
							{
								return 3;
							}
							else
							{
								return 6;
							}
						}
					}
					else
					{
						return 6;
					}
				}
				else
				{
					if(verre.Fe < -0.19)
					{
						if(verre.Al < -1.93 )
						{
							return 1;
						}
						else
						{
							if(verre.Na < 0.93 )
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.RI < -1.27 )
				{
					return 2;
				}
				else
				{
					if(verre.Si < -2.91 )
					{
						return 5;
					}
					else
					{
						if(verre.Mg < -0.72)
						{
							if(verre.K < -0.68)
							{
								if(verre.Al < 1.09 )
								{
									return 7;
								}
								else
								{
									if(verre.Ca < 0.99 )
									{
										return 7;
									}
									else
									{
										return 6;
									}
								}
							}
							else
							{
								return 7;
							}
						}
						else
						{
							return 7;
						}
					}
				}
			}
		}
	}

	public static int ruleRandomK2_S1(VerreClassifieur verre)
	{
		if(verre.Na < 0.69)
		{
			if(verre.RI < -0.35)
			{
				if(verre.RI < -0.88)
				{
					if(verre.Ca < -0.92)
					{
						if(verre.RI < -2.11 )
						{
							return 7;
						}
						else
						{
							return 5;
						}
					}
					else
					{
						if(verre.Ba < 0.42 )
						{
							return 1;
						}
						else
						{
							return 7;
						}
					}
				}
				else
				{
					if(verre.Al < -0.1)
					{
						if(verre.Al < -0.37)
						{
							if(verre.RI < -0.72 )
							{
								return 3;
							}
							else
							{
								if(verre.Al < -0.39 )
								{
									return 2;
								}
								else
								{
									if(verre.Na < -0.52 )
									{
										return 2;
									}
									else
									{
										return 3;
									}
								}
							}
						}
						else
						{
							return 3;
						}
					}
					else
					{
						if(verre.Al < 0.44)
						{
							if(verre.Fe < 1.77)
							{
								if(verre.Na < 0.05 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
							else
							{
								if(verre.Si < 0.1 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
						}
						else
						{
							if(verre.K < 0.15 )
							{
								return 3;
							}
							else
							{
								if(verre.Si < 0.96 )
								{
									return 2;
								}
								else
								{
									return 5;
								}
							}
						}
					}
				}
			}
			else
			{
				if(verre.Al < 0.01)
				{
					if(verre.Si < -0.13)
					{
						if(verre.RI < 0.29 )
						{
							return 2;
						}
						else
						{
							if(verre.Ca < 1.19)
							{
								if(verre.RI < 1.61)
								{
									if(verre.Mg < 0.08 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									if(verre.RI < 1.8 )
									{
										return 7;
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Ca < 0.29)
						{
							if(verre.Si < 0.22)
							{
								if(verre.Ca < -0.24)
								{
									if(verre.Al < -0.55 )
									{
										return 2;
									}
									else
									{
										if(verre.Na < -0.18 )
										{
											return 1;
										}
										else
										{
											if(verre.Mg < 0.73 )
											{
												return 1;
											}
											else
											{
												return 2;
											}
										}
									}
								}
								else
								{
									return 1;
								}
							}
							else
							{
								if(verre.Al < -0.67)
								{
									if(verre.RI < -0.16 )
									{
										return 1;
									}
									else
									{
										if(verre.RI < -0.07 )
										{
											return 3;
										}
										else
										{
											return 2;
										}
									}
								}
								else
								{
									return 1;
								}
							}
						}
						else
						{
							return 2;
						}
					}
				}
				else
				{
					if(verre.Si < 0.38)
					{
						if(verre.Al < 1.26)
						{
							if(verre.Fe < 0.48)
							{
								if(verre.RI < -0.21)
								{
									if(verre.Al < 0.37 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							return 5;
						}
					}
					else
					{
						return 5;
					}
				}
			}
		}
		else
		{
			if(verre.Si < -0.48)
			{
				if(verre.Mg < 0.7)
				{
					if(verre.Si < -1.54)
					{
						if(verre.Si < -2.91 )
						{
							return 5;
						}
						else
						{
							return 7;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.Si < -1.72 )
					{
						return 1;
					}
					else
					{
						if(verre.Na < 1.36 )
						{
							return 3;
						}
						else
						{
							return 1;
						}
					}
				}
			}
			else
			{
				if(verre.Ba < 0.03)
				{
					if(verre.Fe < -0.19 )
					{
						return 6;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 7;
				}
			}
		}
	}

	public static int ruleRandomK2_S2(VerreClassifieur verre)
	{
		if(verre.RI < -0.28)
		{
			if(verre.Al < 0.62)
			{
				if(verre.K < -0.66 )
				{
					return 6;
				}
				else
				{
					if(verre.Ca < -0.43)
					{
						if(verre.Fe < 1.36)
						{
							if(verre.Mg < 0.59 )
							{
								return 2;
							}
							else
							{
								if(verre.Na < 0.06 )
								{
									return 2;
								}
								else
								{
									if(verre.Si < -0.34 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
							}
						}
						else
						{
							if(verre.RI < -0.64 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Si < 0.06 )
						{
							return 3;
						}
						else
						{
							if(verre.Ca < -0.22)
							{
								if(verre.Mg < 0.51 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
							else
							{
								if(verre.RI < -0.58 )
								{
									return 3;
								}
								else
								{
									return 2;
								}
							}
						}
					}
				}
			}
			else
			{
				if(verre.K < -0.14 )
				{
					return 7;
				}
				else
				{
					if(verre.RI < -2.11 )
					{
						return 7;
					}
					else
					{
						if(verre.Mg < 0.14 )
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
				}
			}
		}
		else
		{
			if(verre.Ba < -0.02)
			{
				if(verre.Mg < -0.09)
				{
					if(verre.K < -0.64)
					{
						if(verre.Si < 0.32 )
						{
							return 6;
						}
						else
						{
							if(verre.Na < 0.87 )
							{
								return 2;
							}
							else
							{
								return 6;
							}
						}
					}
					else
					{
						if(verre.RI < 1.25)
						{
							if(verre.Si < -0.23 )
							{
								return 2;
							}
							else
							{
								return 5;
							}
						}
						else
						{
							return 2;
						}
					}
				}
				else
				{
					if(verre.Na < 0.09)
					{
						if(verre.Mg < 0.73)
						{
							if(verre.Si < 0.22)
							{
								if(verre.Na < -0.06)
								{
									if(verre.Si < 0.19)
									{
										if(verre.Fe < 1.41)
										{
											if(verre.Mg < 0.67)
											{
												if(verre.Mg < 0.53)
												{
													if(verre.Na < -0.17 )
													{
														return 1;
													}
													else
													{
														return 2;
													}
												}
												else
												{
													return 1;
												}
											}
											else
											{
												if(verre.Si < -0.16 )
												{
													return 2;
												}
												else
												{
													if(verre.K < 0.05 )
													{
														return 2;
													}
													else
													{
														return 1;
													}
												}
											}
										}
										else
										{
											return 2;
										}
									}
									else
									{
										return 2;
									}
								}
								else
								{
									if(verre.Mg < 0.5 )
									{
										return 7;
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								if(verre.RI < 0 )
								{
									return 1;
								}
								else
								{
									if(verre.Al < -0.77 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
							}
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Ca < -0.25 )
						{
							return 2;
						}
						else
						{
							if(verre.RI < 0.12 )
							{
								return 3;
							}
							else
							{
								if(verre.Na < 0.71)
								{
									if(verre.Na < 0.43 )
									{
										return 1;
									}
									else
									{
										if(verre.Si < -1.82 )
										{
											return 2;
										}
										else
										{
											return 1;
										}
									}
								}
								else
								{
									if(verre.Na < 1.11 )
									{
										return 3;
									}
									else
									{
										return 1;
									}
								}
							}
						}
					}
				}
			}
			else
			{
				if(verre.K < 0.2 )
				{
					return 2;
				}
				else
				{
					if(verre.Ca < -0.59 )
					{
						return 7;
					}
					else
					{
						return 5;
					}
				}
			}
		}
	}

	public static int ruleRandomK2_S3(VerreClassifieur verre)
	{
		if(verre.Na < 0.69)
		{
			if(verre.RI < -0.35)
			{
				if(verre.Al < 0.63)
				{
					if(verre.Ca < -0.43)
					{
						if(verre.Fe < 1.36)
						{
							if(verre.Ca < -0.81 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg < 0.65 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Si < 0.06 )
						{
							return 3;
						}
						else
						{
							if(verre.Mg < 0.51)
							{
								if(verre.Fe < 0.38 )
								{
									return 3;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								if(verre.Na < -0.55 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
						}
					}
				}
				else
				{
					if(verre.Mg < 0.46)
					{
						if(verre.Si < -1.27 )
						{
							return 5;
						}
						else
						{
							if(verre.Al < 0.67 )
							{
								return 7;
							}
							else
							{
								if(verre.Fe < -0.55 )
								{
									return 5;
								}
								else
								{
									return 7;
								}
							}
						}
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.Mg < -0.13)
				{
					if(verre.RI < 1.25)
					{
						if(verre.Ca < 1.72)
						{
							if(verre.Al < 0.85 )
							{
								return 2;
							}
							else
							{
								return 5;
							}
						}
						else
						{
							return 5;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI < -0.05)
					{
						if(verre.RI < -0.13)
						{
							if(verre.K < 0.18 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.K < 0.09 )
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
					else
					{
						if(verre.Mg < 0.72)
						{
							if(verre.Al < -0.14)
							{
								if(verre.Al < -0.55)
								{
									if(verre.RI < 0.23 )
									{
										return 2;
									}
									else
									{
										if(verre.Ca < -0.17 )
										{
											return 2;
										}
										else
										{
											if(verre.Ca < 1.19 )
											{
												return 1;
											}
											else
											{
												return 2;
											}
										}
									}
								}
								else
								{
									if(verre.Si < -0.42 )
									{
										return 1;
									}
									else
									{
										if(verre.RI < 1 )
										{
											return 1;
										}
										else
										{
											return 7;
										}
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Ca < -0.21 )
							{
								return 2;
							}
							else
							{
								if(verre.RI < 0.57 )
								{
									return 2;
								}
								else
								{
									return 1;
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.RI < 0.11)
			{
				if(verre.Mg < -0.92)
				{
					if(verre.Na < 3.44 )
					{
						return 7;
					}
					else
					{
						return 6;
					}
				}
				else
				{
					if(verre.Si < -1.54)
					{
						if(verre.Na < 0.9 )
						{
							return 5;
						}
						else
						{
							return 7;
						}
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.Mg < 0.27)
				{
					if(verre.K < -0.64 )
					{
						return 6;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.Ca < 0.35 )
					{
						return 1;
					}
					else
					{
						return 3;
					}
				}
			}
		}

	}

	public static int ruleRandomK5_S1(VerreClassifieur verre)
	{
		if(verre.Mg < 0.01)
		{
			if(verre.Ca < 0.49)
			{
				if(verre.Al < 2.79)
				{
					if(verre.Al < 0.5 )
					{
						return 6;
					}
					else
					{
						return 7;
					}
				}
				else
				{
					return 5;
				}
			}
			else
			{
				if(verre.K < -0.64)
				{
					if(verre.Na < 0.53 )
					{
						return 2;
					}
					else
					{
						return 6;
					}
				}
				else
				{
					if(verre.Si < 0.24)
					{
						if(verre.Fe < 3.79 )
						{
							return 2;
						}
						else
						{
							return 5;
						}
					}
					else
					{
						return 5;
					}
				}
			}
		}
		else
		{
			if(verre.RI < -0.35)
			{
				if(verre.Ca < -0.43)
				{
					if(verre.RI < -1.94 )
					{
						return 7;
					}
					else
					{
						if(verre.Al < 0.13 )
						{
							return 2;
						}
						else
						{
							if(verre.Fe < 1.26)
							{
								if(verre.K < -0.03)
								{
									if(verre.Na < 0.93 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 1;
							}
						}
					}
				}
				else
				{
					if(verre.RI < -0.84 )
					{
						return 1;
					}
					else
					{
						if(verre.Si < 0.07 )
						{
							return 3;
						}
						else
						{
							if(verre.K < 0.03)
							{
								if(verre.RI < -0.7 )
								{
									return 2;
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
			}
			else
			{
				if(verre.Mg < 0.73)
				{
					if(verre.RI < 0)
					{
						if(verre.Na < 0.08)
						{
							if(verre.Na < -1.24 )
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
						else
						{
							return 3;
						}
					}
					else
					{
						if(verre.K < 0.1)
						{
							if(verre.Ca < -0.14 )
							{
								return 2;
							}
							else
							{
								if(verre.RI < 0.06 )
								{
									return 2;
								}
								else
								{
									if(verre.Si < -1.82 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
							}
						}
						else
						{
							if(verre.Na < -0.12)
							{
								if(verre.Mg < 0.64 )
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 7;
							}
						}
					}
				}
				else
				{
					if(verre.Si < -1.21)
					{
						if(verre.RI < 1.2)
						{
							if(verre.Na < 0.5 )
							{
								return 1;
							}
							else
							{
								return 3;
							}
						}
						else
						{
							return 1;
						}
					}
					else
					{
						return 2;
					}
				}
			}
		}
	}

	public static int ruleRandomK5_S2(VerreClassifieur verre)
	{
		if(verre.Al < 0.62)
		{
			if(verre.K < -0.69)
			{
				if(verre.Ca < 1.22)
				{
					if(verre.Mg < 0.32 )
					{
						return 6;
					}
					else
					{
						return 3;
					}
				}
				else
				{
					if(verre.RI < 1.8)
					{
						if(verre.Si < 1.78 )
						{
							return 6;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.RI < -0.35)
				{
					if(verre.Ca < -0.43)
					{
						if(verre.Al < 0.13 )
						{
							return 2;
						}
						else
						{
							if(verre.RI < -0.6)
							{
								if(verre.Al < 0.4 )
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Si < 0.06 )
						{
							return 3;
						}
						else
						{
							if(verre.Al < -0.46 )
							{
								return 1;
							}
							else
							{
								if(verre.K < 0.03)
								{
									if(verre.RI < -0.7 )
									{
										return 2;
									}
									else
									{
										return 3;
									}
								}
								else
								{
									return 2;
								}
							}
						}
					}
				}
				else
				{
					if(verre.Mg < -0.13)
					{
						if(verre.Si < 0.24 )
						{
							return 2;
						}
						else
						{
							return 5;
						}
					}
					else
					{
						if(verre.RI < -0.05)
						{
							if(verre.Ca < -0.07 )
							{
								return 1;
							}
							else
							{
								if(verre.RI < -0.14)
								{
									if(verre.RI < -0.23 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 3;
								}
							}
						}
						else
						{
							if(verre.K < -0.31)
							{
								if(verre.Mg < 0.38 )
								{
									return 2;
								}
								else
								{
									if(verre.Al < -1.54)
									{
										if(verre.Al < -1.73 )
										{
											return 1;
										}
										else
										{
											return 3;
										}
									}
									else
									{
										return 1;
									}
								}
							}
							else
							{
								if(verre.Ca < -0.13)
								{
									if(verre.Na < -0.63 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
								else
								{
									if(verre.Na < -0.47 )
									{
										return 2;
									}
									else
									{
										if(verre.K < 0.1 )
										{
											return 1;
										}
										else
										{
											if(verre.Mg < 0.45 )
											{
												return 1;
											}
											else
											{
												return 7;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Ba < 0.26)
			{
				if(verre.Si < -0.68 )
				{
					return 5;
				}
				else
				{
					if(verre.Al < 0.73 )
					{
						return 5;
					}
					else
					{
						if(verre.K < -0.24 )
						{
							return 6;
						}
						else
						{
							return 2;
						}
					}
				}
			}
			else
			{
				if(verre.Si < -2.91)
				{
					if(verre.Mg < -0.92 )
					{
						return 2;
					}
					else
					{
						return 5;
					}
				}
				else
				{
					return 7;
				}
			}
		}
	}

	public static int ruleRandomK5_S3(VerreClassifieur verre)
	{
		if(verre.Mg < 0.01)
		{
			if(verre.Ba < 0.29)
			{
				if(verre.Na < 0.69)
				{
					if(verre.Al < 0.01 )
					{
						return 2;
					}
					else
					{
						if(verre.Fe < 0.28 )
						{
							return 5;
						}
						else
						{
							if(verre.Fe < 1.77 )
							{
								return 2;
							}
							else
							{
								if(verre.RI < 1.73 )
								{
									return 5;
								}
								else
								{
									return 2;
								}
							}
						}
					}
				}
				else
				{
					if(verre.RI < 1.01 )
					{
						return 6;
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.K < -0.22 )
				{
					return 7;
				}
				else
				{
					if(verre.Na < -1.27 )
					{
						return 2;
					}
					else
					{
						if(verre.Na < 0.94 )
						{
							return 5;
						}
						else
						{
							return 7;
						}
					}
				}
			}
		}
		else
		{
			if(verre.Ca < -0.43)
			{
				if(verre.K < 1.03)
				{
					if(verre.Al < -0.41)
					{
						if(verre.RI < -0.1 )
						{
							return 1;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na < -0.75)
						{
							if(verre.Al < 0.16 )
							{
								return 2;
							}
							else
							{
								return 1;
							}
						}
						else
						{
							if(verre.K < 0.09)
							{
								if(verre.Mg < 0.59 )
								{
									return 2;
								}
								else
								{
									if(verre.Si < -0.13 )
									{
										return 2;
									}
									else
									{
										if(verre.Na < -0.18 )
										{
											return 1;
										}
										else
										{
											if(verre.RI < -0.68 )
											{
												return 1;
											}
											else
											{
												return 2;
											}
										}
									}
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					return 7;
				}
			}
			else
			{
				if(verre.Fe < 1.26)
				{
					if(verre.Mg < 0.45)
					{
						if(verre.Ca < 0.24)
						{
							if(verre.Na < 0.02 )
							{
								return 1;
							}
							else
							{
								return 7;
							}
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.RI < -0.38)
						{
							if(verre.RI < -0.8 )
							{
								return 1;
							}
							else
							{
								if(verre.Mg < 0.63 )
								{
									return 3;
								}
								else
								{
									return 2;
								}
							}
						}
						else
						{
							if(verre.Ca < -0.19)
							{
								if(verre.Mg < 0.64)
								{
									if(verre.RI < 0.1 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
								else
								{
									if(verre.RI < -0.1 )
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								if(verre.Na < 0.09 )
								{
									return 1;
								}
								else
								{
									if(verre.RI < 0.12 )
									{
										return 3;
									}
									else
									{
										if(verre.K < -0.69 )
										{
											return 3;
										}
										else
										{
											if(verre.Na < 0.71 )
											{
												return 1;
											}
											else
											{
												if(verre.Na < 0.93 )
												{
													return 3;
												}
												else
												{
													return 1;
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					if(verre.Na < -0.44)
					{
						if(verre.Ca < -0.07 )
						{
							return 1;
						}
						else
						{
							if(verre.Na < -1.07 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						return 2;
					}
				}
			}
		}
	}

	public static int ruleRandomK9(VerreClassifieur verre)
	{
		if(verre.Mg < 0.01)
		{
			if(verre.Ba < 0.29)
			{
				if(verre.Na < 0.69)
				{
					if(verre.Na < -0.01)
					{
						if(verre.RI < 1.79 )
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI < 1.01 )
					{
						return 6;
					}
					else
					{
						return 2;
					}
				}
			}
			else
			{
				if(verre.Si < -1.97)
				{
					if(verre.RI < 1.81 )
					{
						return 5;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 7;
				}
			}
		}
		else
		{
			if(verre.Ca < -0.43)
			{
				if(verre.K < 1.03)
				{
					if(verre.Al < -0.41)
					{
						if(verre.RI < -0.1 )
						{
							return 1;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Fe < 1.41)
						{
							if(verre.Mg < 0.59 )
							{
								return 2;
							}
							else
							{
								if(verre.K < 0.09)
								{
									if(verre.RI < -0.11)
									{
										if(verre.RI < -0.78 )
										{
											return 2;
										}
										else
										{
											if(verre.RI < -0.68 )
											{
												return 1;
											}
											else
											{
												if(verre.RI < -0.42 )
												{
													return 2;
												}
												else
												{
													return 1;
												}
											}
										}
									}
									else
									{
										return 2;
									}
								}
								else
								{
									return 2;
								}
							}
						}
						else
						{
							if(verre.RI < -0.64 )
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					return 7;
				}
			}
			else
			{
				if(verre.RI < -0.38)
				{
					if(verre.Si < 0.06 )
					{
						return 3;
					}
					else
					{
						if(verre.RI < -0.84 )
						{
							return 1;
						}
						else
						{
							if(verre.RI < -0.58)
							{
								if(verre.RI < -0.7 )
								{
									return 2;
								}
								else
								{
									return 3;
								}
							}
							else
							{
								return 2;
							}
						}
					}
				}
				else
				{
					if(verre.Na < 0.02)
					{
						if(verre.Mg < 0.68)
						{
							if(verre.Al < -0.09)
							{
								if(verre.Al < -0.68)
								{
									if(verre.RI < 0.67 )
									{
										return 2;
									}
									else
									{
										return 1;
									}
								}
								else
								{
									return 1;
								}
							}
							else
							{
								if(verre.Ca < -0.24 )
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.RI < 0.21)
						{
							if(verre.RI < 0.03 )
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg < 0.45)
							{
								if(verre.RI < 1.96 )
								{
									return 7;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								if(verre.Na < 0.71 )
								{
									return 1;
								}
								else
								{
									if(verre.Na < 1.11 )
									{
										return 3;
									}
									else
									{
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public static int ruleJ48_N2_S2(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									return 3;
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				return 2;
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleJ48_N2_S3(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.RI <= -0.853687)
						{
							return 1;
						}
						else
						{
							if(verre.Fe <= 1.257525)
							{
								return 3;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									if(verre.Ca <= -0.246927)
									{
										return 1;
									}
									else
									{
										return 2;
									}
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.Mg <= 0.450629)
							{
								return 2;
							}
							else
							{
								if(verre.RI <= 0.211281)
								{
									return 3;
								}
								else
								{
									if(verre.Na <= 0.711024)
									{
										return 1;
									}
									else
									{
										if(verre.Na <= 1.085935)
										{
											return 3;
										}
										else
										{
											return 1;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(verre.Si <= -3.035062)
			{
				return 2;
			}
			else
			{
				return 7;
			}
		}
	}

	public static int ruleJ48_N3_S2(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							if(verre.Al <= -0.423003)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N3_S3(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.462082)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						if(verre.Fe <= 1.360816)
						{
							return 2;
						}
						else
						{
							return 1;
						}
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							if(verre.Al <= -0.423003)
							{
								return 1;
							}
							else
							{
								return 2;
							}
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N4_S2(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.122579)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

	public static int ruleJ48_N4_S3(VerreClassifieur verre)
	{
		if(verre.Ba <= 0.161143)
		{
			if(verre.Mg <= -0.199922)
			{
				if(verre.Na <= 0.686836)
				{
					if(verre.Na <= -0.01461)
					{
						if(verre.RI <= 1.122579)
						{
							return 5;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						return 2;
					}
				}
				else
				{
					return 6;
				}
			}
			else
			{
				if(verre.Ca <= -0.444571)
				{
					if(verre.Al <= -0.423003)
					{
						return 1;
					}
					else
					{
						return 2;
					}
				}
				else
				{
					if(verre.RI <= -0.424841)
					{
						if(verre.Si <= 0.061228)
						{
							return 3;
						}
						else
						{
							return 2;
						}
					}
					else
					{
						if(verre.Na <= 0.009578)
						{
							if(verre.Mg <= 0.67661)
							{
								if(verre.Al <= -0.103924)
								{
									return 1;
								}
								else
								{
									return 2;
								}
							}
							else
							{
								return 2;
							}
						}
						else
						{
							if(verre.RI <= 0.211281)
							{
								return 3;
							}
							else
							{
								return 1;
							}
						}
					}
				}
			}
		}
		else
		{
			return 7;
		}
	}

}